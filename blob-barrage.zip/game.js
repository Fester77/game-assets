/* Blob Barrage – JoyMania */
(function () {
'use strict';

// ---------------------------------------------------------------- basics
const FW = 800, FH = 900;               // logical playfield
const PLAYER_Y = FH - 66;
const ASSETS = window.BB_ASSETS;
const LANG = window.BB_LANG;
const SLUG = (function () {
  const parts = location.pathname.split('/').filter(Boolean);
  const i = parts.indexOf('games');
  if (i >= 0 && parts[i + 1]) return parts[i + 1];
  return parts.length ? parts[parts.length - 1].replace(/\.html?$/, '') || 'blob-barrage' : 'blob-barrage';
})();
let lang = (new URLSearchParams(location.search).get('lang') || 'nl').slice(0, 2).toLowerCase();
if (!LANG[lang]) lang = 'en';
const T = k => (LANG[lang] && LANG[lang][k]) || LANG.en[k] || k;
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const TAU = Math.PI * 2;

// seeded rng (game logic only)
let rngState = 1;
function seedRng(s) { rngState = (s >>> 0) || 1; }
function rnd() {
  rngState |= 0; rngState = rngState + 0x6D2B79F5 | 0;
  let t = Math.imul(rngState ^ rngState >>> 15, 1 | rngState);
  t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
const rr = (a, b) => a + rnd() * (b - a);
const ri = (a, b) => Math.floor(rr(a, b + 1));

// ---------------------------------------------------------------- worlds
const WORLDS = [
  { kind: 'shape',   shield: ['#9be15d', '#5fae3a'], bullet: '#ff4f6d', amb: 'pollen', ui: '#2fb36b', dark: '#1d3b2a' },
  { kind: 'mix',     shield: ['#f4c06a', '#c98a35'], bullet: '#ff5a2e', amb: 'sand',   ui: '#e0a33a', dark: '#4a3418' },
  { kind: 'fish',    shield: ['#ff9fb6', '#d86b8c'], bullet: '#fff36b', amb: 'bubble', ui: '#1f9ed1', dark: '#0d3550' },
  { kind: 'monster', shield: ['#e9f6ff', '#9cc3e4'], bullet: '#3a7bff', amb: 'snow',   ui: '#5b8fd0', dark: '#1d3352' },
  { kind: 'mix',     shield: ['#e7a35a', '#a8622c'], bullet: '#8a3cff', amb: 'leaf',   ui: '#e8732e', dark: '#4a2412' },
  { kind: 'shape',   shield: ['#ffb3dc', '#e070b0'], bullet: '#ff3b8d', amb: 'petal',  ui: '#e65aa5', dark: '#1d4f49' },
  { kind: 'monster', shield: ['#7a6a66', '#4a3d3a'], bullet: '#ffb627', amb: 'ember',  ui: '#ff7a3c', dark: '#1a070d' },
  { kind: 'shape',   shield: ['#f6dcff', '#c09ae0'], bullet: '#ff6a3d', amb: 'twinkle',ui: '#8c62d6', dark: '#2a1d4d' },
  { kind: 'drone',   shield: ['#b8c4d6', '#7a8aa6'], bullet: '#ff4fd8', amb: 'star',   ui: '#4f8cff', dark: '#0b0c2a' },
  { kind: 'drone',   shield: ['#a8f0ff', '#5fb4d6'], bullet: '#ffe84f', amb: 'star',   ui: '#9b5cff', dark: '#0e0a2a' }
];
const BOSS_NAMES = ['Grombo', 'Zandrak', 'Blubbor', 'Frostug', 'Rossik', 'Pinkara', 'Magmox', 'Solaron', 'Gyro-X', 'Omnitron'];
const BOSS_ATTACKS = [
  ['aimed', 'summon', 'aimed', 'spread'],
  ['spread', 'aimed', 'summon'],
  ['rain', 'aimed', 'summon', 'spread'],
  ['spread', 'rain', 'aimed', 'summon'],
  ['aimed', 'spread', 'summon', 'aimed'],
  ['spiral', 'summon', 'dash', 'spread', 'aimed'],
  ['rain', 'aimed', 'dash', 'spread', 'summon'],
  ['spread', 'spiral', 'summon', 'aimed'],
  ['ring', 'aimed', 'rain', 'summon', 'spread'],
  ['ring', 'spiral', 'spread', 'summon', 'dash', 'aimed']
];

// 40 formations (4 per world). 0 = basic, 1 = tough, 2 = elite
const FORMATIONS = [
  // Zonnige Weide
  ['..2222..', '.111111.', '00000000'],
  ['2.2.2.2.2', '111111111', '0.0.0.0.0', '000000000'],
  ['11....11', '222..222', '0000000000'.slice(0, 8), '00000000'],
  ['...22...', '..1111..', '.000000.', '00000000'],
  // Gouden Woestijn
  ['2222222222', '1111111111', '0000000000'],
  ['0........0', '10......01', '210....012', '2210..0122'],
  ['...2222...', '..111111..', '.00000000.', '0000000000'],
  ['22..22..22', '11..11..11', '0000000000', '0000000000'],
  // Koraalrif
  ['.2.2.2.2.2.', '11111111111', '.0.0.0.0.0.', '00000000000'],
  ['....22....', '...1111...', '..000000..', '.00000000.', '0000000000'],
  ['2222.2222', '1111.1111', '0000.0000', '0000.0000'],
  ['0.0.0.0.0.0', '.1.1.1.1.1.', '2.2.2.2.2.2', '.0.0.0.0.0.', '0.0.0.0.0.0'],
  // Sneeuwtoppen
  ['22222222222', '11111111111', '00000000000', '00000000000'],
  ['2.........2', '12.......21', '012.....210', '0012...2100', '00012.21000'],
  ['.222.222.', '11111111111'.slice(0, 9), '000000000', '0.00000.0', '0...0...0'],
  ['..2222222..', '.111111111.', '00000000000', '.000000000.', '..0000000..'],
  // Herfstbos
  ['2.2.2.2.2.2', '11111111111', '11111111111', '00000000000', '00000000000'],
  ['22.....22', '111...111', '0000.0000', '000000000', '.0000000.'],
  ['....2....', '...212...', '..21012..', '.2100012.', '210000012'],
  ['2222222222', '1........1', '1.000000.1', '1.000000.1', '0000000000'],
  // Snoepkasteel
  ['.22...22.', '2112.2112', '100010001', '.1000001.', '..10001..', '...101...'],
  ['22222222222', '1.1.1.1.1.1', '11111111111', '0.0.0.0.0.0', '00000000000'],
  ['2...2...2', '12.121.21', '010101010', '000000000', '000000000'],
  ['22222222222', '21111111112', '21000000012', '21000000012', '00000000000'],
  // Lavavallei
  ['2.2.2.2.2.2', '.2.2.2.2.2.', '11111111111', '00000000000', '00000000000'],
  ['222....222', '2112..2112', '10001100011'.slice(0, 10), '0000000000', '0000000000'],
  ['.22222222.', '2111111112', '1100000011', '1000000001', '0000000000'],
  ['2.........2', '22.......22', '111.....111', '0000...0000', '00000000000', '00000000000'],
  // Wolkenrijk
  ['22222222222', '22222222222', '11111111111', '00000000000', '00000000000'],
  ['...22222...', '.221111122.', '21100000112', '10000000001', '00000000000'],
  ['2.2.2.2.2.2', '1.1.1.1.1.1', '01010101010', '00000000000', '00000000000'],
  ['2222.2.2222', '1111.1.1111', '0000.0.0000', '00000000000', '00000000000', '.0.0.0.0.0.'],
  // Sterrenbaan
  ['22222222222', '11111111111', '11111111111', '00000000000', '00000000000'],
  ['.2.2.2.2.2.', '2.2.2.2.2.2', '11111111111', '00000000000', '00000000000', '00000000000'],
  ['22.22.22.22'.slice(0, 11), '11111111111', '10101010101', '00000000000', '00000000000'],
  ['2222222222', '2111111112', '2100000012', '1000000001', '0000000000', '0000000000'],
  // Nevelkern
  ['22222222222', '22222222222', '11111111111', '11111111111', '00000000000'],
  ['2.2.2.2.2.2', '22222222222', '11111111111', '10101010101', '00000000000', '00000000000'],
  ['..2222222..', '.222222222.', '11111111111', '11111111111', '00000000000', '00000000000'],
  ['22222222222', '21111111112', '21111111112', '10000000001', '00000000000', '00000000000']
];

function levelInfo(n) {
  const w = Math.floor((n - 1) / 5), sub = (n - 1) % 5;
  const d = (n - 1) / 49;
  return {
    n, w, sub, d, boss: sub === 4,
    formation: sub < 4 ? FORMATIONS[w * 4 + sub] : null,
    speed: 26 + 44 * d,
    step: 11 + 5 * d,
    fireInt: 1.45 - 0.95 * d,
    maxBullets: 2 + Math.round(4 * d),
    bulletSpeed: 200 + 130 * d,
    aimChance: d < 0.12 ? 0 : 0.12 + 0.43 * d,
    diveRate: w >= 2 ? 0.015 + 0.09 * d : 0,
    hp: [1, d < 0.22 ? 1 : 2, d < 0.5 ? 2 : 3],
    startY: 112 + 16 * d,
    shields: w < 6 ? 4 : 3,
    bossHp: 40 + w * 15
  };
}

// ---------------------------------------------------------------- state
let headless = false;         // true during bot simulation (dev)
let G = null;                 // current game
let screen = 'loading';       // loading | menu | levels | help | play | pause | result
const save = { levels: {}, music: true, sfx: true };
let user = null;
let controls = {
  keys: { forward: 'KeyW', left: 'KeyA', back: 'KeyS', right: 'KeyD', primary: 'Mouse0', secondary: 'Mouse2', special: 'Mouse1', interact: 'KeyE', jump: 'Space', sprint: 'ShiftLeft', camera: 'KeyV' },
  sensitivity: 1, invertY: false
};
let lastLevel = 1;

// ---------------------------------------------------------------- canvas
const canvas = document.getElementById('game');
let ctx = canvas.getContext('2d');
let VW = 1, VH = 1, DPR = 1, FS = 1, FX = 0, FY = 0;   // field scale + offset (css px)
let touchMode = false;

function resize() {
  VW = window.innerWidth; VH = window.innerHeight;
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(VW * DPR); canvas.height = Math.round(VH * DPR);
  canvas.style.width = VW + 'px'; canvas.style.height = VH + 'px';
  const portrait = VH > VW * 1.05;
  const reserve = touchMode && portrait ? Math.min(150, VH * 0.2) : 0;
  const avH = VH - reserve;
  FS = Math.min(VW / FW, avH / FH);
  FX = (VW - FW * FS) / 2;
  FY = touchMode && portrait ? Math.max(0, (avH - FH * FS) / 2) : (VH - FH * FS) / 2;
  document.body.classList.toggle('portrait', portrait);
  const tc = document.getElementById('touch');
  const bs = document.body.style;
  bs.setProperty('--fx', FX + 'px'); bs.setProperty('--fy', FY + 'px');
  bs.setProperty('--fw', (FW * FS) + 'px'); bs.setProperty('--fh', (FH * FS) + 'px'); bs.setProperty('--fs', FS);
}

// ---------------------------------------------------------------- images
const IMG = {};
function loadImg(name, src) {
  return new Promise(res => {
    const im = new Image();
    im.onload = () => { IMG[name] = im; res(); };
    im.onerror = () => res();
    im.src = src;
  });
}
const AT = ASSETS.atlas;
function spr(name, x, y, scale, opts) {
  const a = AT[name]; const im = IMG.sprites;
  if (!a || !im) return;
  const w = a[2] * scale, h = a[3] * scale;
  if (opts) {
    ctx.save();
    ctx.translate(x, y);
    if (opts.rot) ctx.rotate(opts.rot);
    ctx.scale((opts.flip ? -1 : 1) * (opts.sx || 1), opts.sy || 1);
    if (opts.alpha != null) ctx.globalAlpha *= opts.alpha;
    ctx.drawImage(im, a[0], a[1], a[2], a[3], -w / 2, -h / 2, w, h);
    if (opts.flash > 0) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = Math.min(1, opts.flash);
      ctx.drawImage(im, a[0], a[1], a[2], a[3], -w / 2, -h / 2, w, h);
    }
    ctx.restore();
  } else {
    ctx.drawImage(im, a[0], a[1], a[2], a[3], x - w / 2, y - h / 2, w, h);
  }
}
const sprW = (name, s) => AT[name] ? AT[name][2] * s : 0;
const sprH = (name, s) => AT[name] ? AT[name][3] * s : 0;

// ---------------------------------------------------------------- audio (WebAudio, all synthesized)
const Snd = (function () {
  let ac = null, master, musicBus, sfxBus, noiseBuf;
  let musicOn = true;
  let seq = null;
  function init() {
    if (ac || headless) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { ac = new AC(); } catch (e) { ac = null; return; }
    master = ac.createGain(); master.gain.value = 0.8; master.connect(ac.destination);
    const comp = ac.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4; comp.connect(master);
    musicBus = ac.createGain(); musicBus.gain.value = musicOn ? 0.32 : 0; musicBus.connect(comp);
    sfxBus = ac.createGain(); sfxBus.gain.value = 0.55; sfxBus.connect(comp);
    noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  function resume() { init(); if (ac && ac.state === 'suspended') ac.resume(); }
  function env(g, t, a, peak, dcy, sus, rel, dur) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak * sus), t + a + dcy);
    g.gain.setValueAtTime(Math.max(0.0001, peak * sus), t + Math.max(a + dcy, dur));
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + dcy, dur) + rel);
  }
  function tone(type, f0, f1, t, dur, vol, bus, opts) {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    if (opts && opts.vib) {
      const l = ac.createOscillator(), lg = ac.createGain();
      l.frequency.value = opts.vib; lg.gain.value = f0 * 0.012; l.connect(lg); lg.connect(o.frequency); l.start(t); l.stop(t + dur + 0.3);
    }
    let node = o;
    if (opts && opts.lp) { const f = ac.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = opts.lp; o.connect(f); node = f; }
    node.connect(g); g.connect(bus || sfxBus);
    env(g, t, (opts && opts.a) || 0.004, vol, (opts && opts.d) || dur * 0.4, (opts && opts.s) || 0.4, (opts && opts.r) || 0.06, dur);
    o.start(t); o.stop(t + dur + 0.4);
  }
  function noise(t, dur, vol, ftype, f0, f1, bus, q) {
    const s = ac.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = ac.createBiquadFilter(); f.type = ftype; f.frequency.setValueAtTime(f0, t);
    if (f1) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    if (q) f.Q.value = q;
    const g = ac.createGain();
    s.connect(f); f.connect(g); g.connect(bus || sfxBus);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }
  const lastPlay = {};
  function sfx(name, p) {
    if (!ac || headless || !save.sfx) return;
    const t = ac.currentTime;
    if (lastPlay[name] && t - lastPlay[name] < 0.035) return;
    lastPlay[name] = t;
    switch (name) {
      case 'shoot': tone('square', 1250, 620, t, 0.07, 0.07, null, { lp: 3500, s: 0.3 }); tone('triangle', 620, 310, t, 0.06, 0.08); break;
      case 'hit': tone('triangle', 520, 330, t, 0.06, 0.15); noise(t, 0.05, 0.1, 'highpass', 2500); break;
      case 'kill': {
        const base = 380 + (p || 0) * 60;
        tone('sine', base * 1.8, base * 0.45, t, 0.14, 0.22); noise(t, 0.18, 0.18, 'bandpass', 1800, 300, null, 0.8); break;
      }
      case 'shieldHit': noise(t, 0.05, 0.12, 'bandpass', 900, 500, null, 2); break;
      case 'playerHit': tone('sawtooth', 220, 50, t, 0.5, 0.25, null, { lp: 900 }); noise(t, 0.6, 0.35, 'lowpass', 1600, 80); break;
      case 'power': [523, 659, 784, 1047].forEach((f, i) => tone('square', f, f, t + i * 0.055, 0.07, 0.08, null, { lp: 4000 })); break;
      case 'life': [392, 523, 659, 784, 1047, 1319].forEach((f, i) => tone('triangle', f, f, t + i * 0.05, 0.08, 0.16)); break;
      case 'shieldPop': tone('sine', 900, 200, t, 0.25, 0.2); noise(t, 0.25, 0.15, 'highpass', 3000); break;
      case 'bonusNote': tone('triangle', p, p, t, 0.09, 0.07, null, { s: 0.6 }); tone('sine', p * 2, p * 2, t, 0.06, 0.03); break;
      case 'bonusKill': tone('sine', 988, 988, t, 0.08, 0.2); tone('sine', 1319, 1319, t + 0.08, 0.25, 0.2); tone('triangle', 1976, 1976, t + 0.16, 0.2, 0.08); break;
      case 'bossHit': tone('square', 160, 90, t, 0.07, 0.1, null, { lp: 1200 }); break;
      case 'bossShot': tone('sawtooth', 300, 140, t, 0.12, 0.07, null, { lp: 1400 }); break;
      case 'bigBoom': tone('sine', 140, 30, t, 1.0, 0.4); noise(t, 1.2, 0.45, 'lowpass', 2500, 60); break;
      case 'dive': tone('sine', 1400, 500, t, 0.35, 0.06, null, { vib: 18 }); break;
      case 'warn': [0, 0.28, 0.56].forEach(o => tone('square', 440, 440, t + o, 0.16, 0.06, null, { lp: 2000 })); break;
      case 'star': tone('triangle', p, p, t, 0.18, 0.18); tone('sine', p * 2, p * 2, t + 0.02, 0.2, 0.06); break;
      case 'click': tone('triangle', 900, 700, t, 0.04, 0.08); break;
      case 'win': [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => tone('square', f, f, t + i * 0.09, 0.12, 0.08, null, { lp: 3500 })); break;
      case 'lose': [440, 415, 392, 330].forEach((f, i) => tone('triangle', f, f * 0.98, t + i * 0.2, 0.22, 0.16)); break;
    }
  }

  // ---- music: tiny generative tracker, one style per world
  const STYLES = [
    { bpm: 118, root: 60, scale: [0, 2, 4, 7, 9], prog: [0, 5, 3, 4], lead: 'square', bass: 'triangle', swing: 0 },
    { bpm: 104, root: 57, scale: [0, 1, 4, 5, 7, 8, 10], prog: [0, 0, 6, 5], lead: 'sawtooth', bass: 'triangle', swing: 0.08 },
    { bpm: 96,  root: 62, scale: [0, 2, 4, 7, 9], prog: [0, 3, 5, 4], lead: 'sine', bass: 'sine', swing: 0.12 },
    { bpm: 112, root: 64, scale: [0, 2, 3, 5, 7, 9, 10], prog: [0, 6, 3, 4], lead: 'triangle', bass: 'triangle', swing: 0 },
    { bpm: 122, root: 55, scale: [0, 2, 4, 5, 7, 9, 11], prog: [0, 4, 5, 3], lead: 'square', bass: 'triangle', swing: 0.05 },
    { bpm: 132, root: 65, scale: [0, 2, 4, 7, 9], prog: [0, 5, 1, 4], lead: 'square', bass: 'square', swing: 0 },
    { bpm: 126, root: 52, scale: [0, 2, 3, 5, 7, 8, 10], prog: [0, 5, 6, 4], lead: 'sawtooth', bass: 'sawtooth', swing: 0 },
    { bpm: 100, root: 61, scale: [0, 2, 4, 6, 7, 9, 11], prog: [0, 1, 4, 3], lead: 'triangle', bass: 'sine', swing: 0.1 },
    { bpm: 128, root: 58, scale: [0, 2, 3, 5, 7, 9, 10], prog: [0, 3, 6, 4], lead: 'square', bass: 'sawtooth', swing: 0 },
    { bpm: 138, root: 54, scale: [0, 1, 3, 5, 7, 8, 10], prog: [0, 6, 5, 4], lead: 'sawtooth', bass: 'sawtooth', swing: 0 }
  ];
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  function makeSong(styleIdx, boss, menu) {
    const st = Object.assign({}, STYLES[styleIdx]);
    if (boss) { st.bpm += 18; st.scale = [0, 2, 3, 5, 7, 8, 10]; st.prog = [0, 5, 6, 4]; }
    if (menu) { st.bpm = 108; }
    // deterministic melody per world
    let s = 9973 * (styleIdx + 1) + (boss ? 77 : 0) + (menu ? 555 : 0);
    const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    const sc = st.scale;
    const deg = (d) => { const o = Math.floor(d / sc.length); const i = ((d % sc.length) + sc.length) % sc.length; return sc[i] + 12 * o; };
    const chordRoot = i => [0, 2, 4, 3, 4, 5, 6, 1][i] | 0;
    // two 2-bar phrases, A A' B A
    const phrase = () => {
      const notes = []; let cur = ri0(2, 6);
      for (let i = 0; i < 16; i++) {
        if (r() < (i % 4 === 0 ? 0.92 : i % 2 === 0 ? 0.6 : 0.28)) { cur = clamp(cur + Math.round((r() - 0.5) * 4), 0, 9); notes.push({ i, d: cur, len: r() < 0.3 ? 2 : 1 }); }
      }
      return notes;
    };
    function ri0(a, b) { return a + Math.floor(r() * (b - a + 1)); }
    const A = phrase(), B = phrase(), A2 = A.map(n => ({ i: n.i, d: n.i >= 12 ? n.d + 2 : n.d, len: n.len }));
    st.melody = [A, A2, B, A];
    st.deg = deg; st.chordRoot = chordRoot;
    return st;
  }
  function startMusic(world, boss, menu) {
    if (headless) return;
    init();
    stopMusic();
    if (!ac) return;
    const song = makeSong(world, boss, menu);
    seq = { song, step: 0, next: ac.currentTime + 0.12, timer: null };
    const stepDur = 60 / song.bpm / 4;
    seq.timer = setInterval(() => {
      if (!seq || !ac) return;
      while (seq.next < ac.currentTime + 0.18) { playStep(seq.song, seq.step, seq.next, stepDur); seq.next += stepDur; seq.step = (seq.step + 1) % 128; }
    }, 30);
  }
  function playStep(st, step, t, sd) {
    if (!musicOn) return;
    const bar = Math.floor(step / 16) % 8, inBar = step % 16;
    const chordIdx = st.prog[Math.floor(step / 32) % 4];
    const croot = st.root + st.deg(chordIdx);
    const sw = (inBar % 2 === 1) ? st.swing * sd : 0;
    t += sw;
    // drums
    if (inBar % 8 === 0) tone('sine', 150, 45, t, 0.16, 0.5, musicBus, { d: 0.12, s: 0.01, r: 0.03 });
    if (inBar % 8 === 4) noise(t, 0.12, 0.22, 'bandpass', 1900, 900, musicBus, 0.9);
    if (inBar % 2 === 0) noise(t, 0.035, inBar % 4 === 2 ? 0.09 : 0.05, 'highpass', 7000, null, musicBus);
    if (bar % 4 === 3 && inBar >= 12) noise(t, 0.08, 0.12, 'bandpass', 1200 + inBar * 100, 600, musicBus, 1.2);
    // bass
    if (inBar % 2 === 0) {
      const pat = [0, 0, 7, 0, 12, 7, 0, 5];
      const n = croot - 24 + pat[(inBar / 2) | 0];
      tone(st.bass, mtof(n), mtof(n), t, sd * 1.6, 0.16, musicBus, { lp: 900, s: 0.5, r: 0.04 });
    }
    // arpeggio
    if (step >= 32 || true) {
      const ch = [0, 2, 4, 7].map(k => st.root + st.deg(chordIdx + k));
      const n = ch[inBar % 4] + 12;
      tone('square', mtof(n), mtof(n), t, sd * 0.7, 0.025, musicBus, { lp: 2200, s: 0.2, r: 0.03 });
    }
    // melody (enters after 2 bars)
    if (step >= 32) {
      const ph = st.melody[Math.floor(step / 32) % 4];
      const local = step % 32;
      if (local % 2 === 0) {
        const note = ph.find(n => n.i === local / 2);
        if (note) {
          const m = st.root + 12 + st.deg(note.d + chordIdx % 2);
          tone(st.lead, mtof(m), mtof(m), t, sd * 2 * note.len * 0.9, st.lead === 'sine' ? 0.11 : 0.06, musicBus, { lp: 3200, vib: 5.5, s: 0.55, r: 0.08 });
        }
      }
    }
  }
  function stopMusic() { if (seq && seq.timer) clearInterval(seq.timer); seq = null; }
  function setMusic(on) {
    musicOn = on;
    if (ac && musicBus) musicBus.gain.setTargetAtTime(on ? 0.32 : 0, ac.currentTime, 0.05);
  }
  function suspend(b) { if (!ac) return; if (b) ac.suspend(); else ac.resume(); }
  return { init, resume, sfx, startMusic, stopMusic, setMusic, suspend, get ready() { return !!ac; } };
})();

// ---------------------------------------------------------------- input
const keys = new Set();
const mouseBtn = new Set();
const touchBtn = { left: false, right: false, fire: false };
let dragTouch = null;     // {id, lastX}
let mouseAbsX = null, lockedDX = 0, pointerLocked = false, mouseInField = false;
const ARROW_FIRE = ['Space', 'ArrowUp'];
let fireLatch = false;   // a quick tap between two frames still fires
function bound(action) {
  const c = controls.keys[action];
  if (!c) return false;
  if (c.indexOf('Mouse') === 0) return mouseBtn.has(c);
  return keys.has(c);
}
function readInput() {
  const left = keys.has('ArrowLeft') || bound('left') || touchBtn.left;
  const right = keys.has('ArrowRight') || bound('right') || touchBtn.right;
  const fire = fireLatch || bound('primary') || bound('jump') || bound('forward') || ARROW_FIRE.some(k => keys.has(k)) || touchBtn.fire || !!dragTouch;
  fireLatch = false;
  return { left, right, fire };
}

// ---------------------------------------------------------------- game creation
function makeShield(cx, cy, w) {
  const cols = 22, rows = 13, cs = 4;
  const cells = new Uint8Array(cols * rows);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let on = 1;
    const dx = c < cols / 2 ? c : cols - 1 - c;
    if (r < 4 && dx < 4 - r) on = 0;               // rounded top corners
    if (r >= rows - 4 && c >= 7 && c <= 14) {        // arch underneath
      const ax = (c - 10.5) / 4.2, ay = (rows - 0.5 - r) / 4.2;
      if (ax * ax + ay * ay < 1.05) on = 0;
    }
    cells[r * cols + c] = on;
  }
  const s = { x: cx - cols * cs / 2, y: cy, cols, rows, cs, cells, dirty: true, cv: null, count: 0 };
  return s;
}

function newGame(n, opts) {
  opts = opts || {};
  const L = levelInfo(n);
  seedRng(opts.seed != null ? opts.seed : (Date.now() ^ (n * 7919)));
  const g = {
    L, n, t: 0, playT: 0, state: 'intro', stateT: 0,
    score: 0, kills: 0, lives: 3, hits: 0,
    player: { x: FW / 2, y: PLAYER_Y, vx: 0, cd: 0, inv: 0, dead: 0, double: 0, rapid: 0, shield: 0, tilt: 0 },
    pbul: [], ebul: [], enemies: [], pups: [], fx: [], parts: [], amb: [], floats: [],
    form: null, boss: null, bonus: null, bonusT: rr(14, 22),
    shields: [], fireT: 1.5, shake: 0, flashScreen: 0, result: null, noteT: 0, noteI: 0,
    world: WORLDS[L.w]
  };
  // shields
  const ns = L.shields;
  for (let i = 0; i < ns; i++) g.shields.push(makeShield(FW * (i + 1) / (ns + 1), FH - 205));
  if (!L.boss) {
    const rows = L.formation;
    const cols = Math.max(...rows.map(r => r.length));
    const cw = Math.min(62, (FW - 68 - 230) / Math.max(1, cols - 1)), chh = 52;
    const fw = (cols - 1) * cw;
    g.form = { es: Math.min(0.6, (cw - 3) / 96), x: (FW - fw) / 2, y: -rows.length * chh - 40, targetY: L.startY, dir: 1, speed: L.speed, down: 0, cw, ch: chh, cols, rows: rows.length };
    rows.forEach((row, r) => {
      for (let c = 0; c < row.length; c++) {
        const ch = row[c]; if (ch === '.') continue;
        const type = +ch;
        // centre shorter rows
        const off = (cols - row.length) / 2;
        g.enemies.push(makeEnemy(g, type, c + off, r));
      }
    });
    g.total = g.enemies.length;
  } else {
    const w = L.w;
    g.boss = {
      idx: w, x: FW / 2, y: -220, baseY: 200, hp: L.bossHp, maxhp: L.bossHp, t: 0, phase: 0, flash: 0,
      atkT: 2.4, atkI: 0, queue: [], dash: null, scale: w >= 8 ? 0.62 : 0.56, rot: 0, pods: w >= 9 ? 4 : w >= 8 ? 3 : 0, podT: 1.5, dying: 0
    };
    g.total = 1;
  }
  // ambient particles
  for (let i = 0; i < 26; i++) g.amb.push(newAmb(g, true));
  return g;
}
function makeEnemy(g, type, col, row) {
  const L = g.L;
  return {
    type, col, row, x: 0, y: 0, hp: L.hp[type], maxhp: L.hp[type], alive: true, flash: 0,
    mode: 'form', vx: 0, vy: 0, t: rr(0, 6), spr: 'e' + L.w + '_' + type, shot: false
  };
}
function newAmb(g, init) {
  const k = g.world.amb;
  const a = { k, x: rnd() * FW, y: init ? rnd() * FH : -10, s: rr(0.6, 1.4), t: rnd() * 10, vx: 0, vy: 0 };
  switch (k) {
    case 'bubble': a.y = init ? rnd() * FH : FH + 10; a.vy = -rr(20, 50); break;
    case 'snow': a.vy = rr(25, 60); a.vx = rr(-10, 10); break;
    case 'leaf': case 'petal': a.vy = rr(30, 55); a.vx = rr(-25, 25); break;
    case 'ember': a.y = init ? rnd() * FH : FH + 10; a.vy = -rr(20, 60); a.vx = rr(-8, 8); break;
    case 'sand': a.vx = rr(40, 90); a.vy = rr(-4, 4); a.x = init ? rnd() * FW : -10; a.y = rnd() * FH; break;
    case 'pollen': a.vy = rr(-8, 8); a.vx = rr(-12, 12); a.y = rnd() * FH; break;
    default: a.y = rnd() * FH; break;
  }
  return a;
}

// ---------------------------------------------------------------- helpers
function formPos(g, e) {
  const f = g.form;
  return { x: f.x + e.col * f.cw, y: f.y + e.row * f.ch };
}
function enemyBox(e) { return 21; }
function addFx(g, x, y, scale, kind) { g.fx.push({ x, y, t: 0, s: scale || 1, kind: kind || 'ex' }); }
function burst(g, x, y, col, n, spd) {
  for (let i = 0; i < n; i++) {
    const a = rnd() * TAU, v = rr(0.3, 1) * (spd || 200);
    g.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: rr(0.35, 0.8), t: 0, col, r: rr(2, 5) });
  }
}
function floatText(g, x, y, txt, col) { g.floats.push({ x, y, txt, col: col || '#fff', t: 0 }); }
function addScore(g, v) { g.score += Math.round(v); }

function shieldHit(g, x, y, rad, power) {
  for (const s of g.shields) {
    if (x < s.x - rad || x > s.x + s.cols * s.cs + rad || y < s.y - rad || y > s.y + s.rows * s.cs + rad) continue;
    const cx = Math.floor((x - s.x) / s.cs), cy = Math.floor((y - s.y) / s.cs);
    const rc = Math.ceil(rad / s.cs);
    let hit = false;
    for (let r = cy - rc; r <= cy + rc && !hit; r++) for (let c = cx - rc; c <= cx + rc; c++) {
      if (r < 0 || c < 0 || r >= s.rows || c >= s.cols) continue;
      if (s.cells[r * s.cols + c]) { hit = true; break; }
    }
    if (!hit) continue;
    const pr = power || 2.6;
    for (let r = cy - 4; r <= cy + 4; r++) for (let c = cx - 4; c <= cx + 4; c++) {
      if (r < 0 || c < 0 || r >= s.rows || c >= s.cols) continue;
      const d = Math.hypot(r - cy, c - cx);
      if (d < pr * 0.6 || (d < pr + 0.8 && rnd() < 0.55)) s.cells[r * s.cols + c] = 0;
    }
    s.dirty = true;
    burst(g, x, y, g.world.shield[0], 4, 90);
    return true;
  }
  return false;
}
function eraseShieldRect(g, x0, y0, x1, y1) {
  for (const s of g.shields) {
    if (x1 < s.x || x0 > s.x + s.cols * s.cs || y1 < s.y || y0 > s.y + s.rows * s.cs) continue;
    for (let r = 0; r < s.rows; r++) for (let c = 0; c < s.cols; c++) {
      const cx = s.x + c * s.cs, cy = s.y + r * s.cs;
      if (cx + s.cs > x0 && cx < x1 && cy + s.cs > y0 && cy < y1 && s.cells[r * s.cols + c]) { s.cells[r * s.cols + c] = 0; s.dirty = true; }
    }
  }
}

function spawnEnemyBullet(g, x, y, vx, vy, kind) {
  g.ebul.push({ x, y, vx, vy, r: kind === 'big' ? 9 : 6, kind: kind || 'n', t: 0, age: 0 });
}
function aimAt(g, x, y, speed, spreadDeg) {
  const p = g.player;
  let a = Math.atan2(p.y - y, p.x - x);
  if (spreadDeg) a += spreadDeg * Math.PI / 180;
  return { vx: Math.cos(a) * speed, vy: Math.sin(a) * speed };
}

// ---------------------------------------------------------------- update
function update(g, dt, inp) {
  g.t += dt; g.stateT += dt;
  if (g.state === 'play' || g.state === 'intro') g.playT += dt;
  if (g.shake > 0) g.shake = Math.max(0, g.shake - dt * 20);
  if (g.flashScreen > 0) g.flashScreen = Math.max(0, g.flashScreen - dt * 3);
  updateAmb(g, dt);
  updateFx(g, dt);
  if (g.state === 'intro') {
    updatePlayer(g, dt, inp, false);
    if (g.form) {
      const f = g.form; f.y = lerp(f.y, f.targetY, 1 - Math.pow(0.02, dt)); placeFormation(g, dt);
      if (g.stateT > 1.8) { f.y = f.targetY; g.state = 'play'; g.stateT = 0; }
    } else {
      const b = g.boss; b.t += dt; b.y = lerp(b.y, b.baseY, 1 - Math.pow(0.05, dt));
      if (g.stateT > 2.2) { g.state = 'play'; g.stateT = 0; }
    }
    return;
  }
  if (g.state === 'clear' || g.state === 'over') {
    updatePlayer(g, dt, inp, false);
    updateBullets(g, dt);
    if (g.boss && g.boss.dying > 0) updateBossDeath(g, dt);
    if (g.stateT > (g.state === 'clear' ? (g.boss ? 2.6 : 1.4) : 1.6)) finishLevel(g, g.state === 'clear');
    return;
  }
  // play
  updatePlayer(g, dt, inp, true);
  if (g.form) updateFormation(g, dt);
  if (g.boss) updateBoss(g, dt);
  updateEnemies(g, dt);
  updateBonus(g, dt);
  updateBullets(g, dt);
  updatePowerups(g, dt);
  collide(g);
  // win / lose
  if (g.state === 'play') {
    const anyAlive = g.enemies.some(e => e.alive);
    if (g.form && !anyAlive) win(g);
    if (g.boss && g.boss.hp <= 0 && g.boss.dying === 0) { bossDie(g); }
    if (g.lives <= 0) lose(g, 'lives');
  }
}

function updatePlayer(g, dt, inp, canFire) {
  const p = g.player;
  const speed = 380;
  let ax = 0;
  if (inp.left) ax -= 1;
  if (inp.right) ax += 1;
  if (p.dead > 0) { p.dead -= dt; ax = 0; }
  if (ax !== 0) { p.vx = ax * speed; }
  else p.vx = 0;
  let dx = p.vx * dt;
  if (inp.dx) dx += inp.dx;                         // pointer lock / drag (direct)
  if (inp.targetX != null) {                        // absolute mouse fallback
    const diff = inp.targetX - p.x; const m = speed * 1.3 * dt;
    dx += clamp(diff, -m, m);
  }
  if (p.dead > 0) dx = 0;
  p.x = clamp(p.x + dx, 34, FW - 34);
  p.tilt = lerp(p.tilt, clamp(dx / dt / speed, -1, 1) * 0.18, 1 - Math.pow(0.001, dt));
  p.cd -= dt; if (p.inv > 0) p.inv -= dt;
  if (p.double > 0) p.double -= dt;
  if (p.rapid > 0) p.rapid -= dt;
  if (p.shield > 0) p.shield -= dt;
  if (canFire && inp.fire && p.cd <= 0 && p.dead <= 0) {
    const maxB = p.rapid > 0 ? 6 : 3;
    const live = g.pbul.length;
    if (live < maxB * (p.double > 0 ? 2 : 1)) {
      p.cd = p.rapid > 0 ? 0.13 : 0.3;
      if (p.double > 0) { g.pbul.push({ x: p.x - 13, y: p.y - 26, vy: -760 }); g.pbul.push({ x: p.x + 13, y: p.y - 26, vy: -760 }); }
      else g.pbul.push({ x: p.x, y: p.y - 30, vy: -760 });
      Snd.sfx('shoot');
    }
  }
}

function placeFormation(g, dt) {
  for (const e of g.enemies) {
    if (!e.alive || e.mode !== 'form') continue;
    const p = formPos(g, e); e.x = p.x; e.y = p.y;
  }
}
function updateFormation(g, dt) {
  const f = g.form, L = g.L;
  const alive = g.enemies.filter(e => e.alive);
  const frac = alive.length / g.total;
  const spd = f.speed * (1 + 1.7 * Math.pow(1 - frac, 1.6));
  if (f.down > 0) {
    const m = Math.min(f.down, 90 * dt); f.y += m; f.down -= m;
  } else {
    f.x += f.dir * spd * dt;
    let minX = 1e9, maxX = -1e9;
    for (const e of alive) { if (e.mode !== 'form') continue; const x = f.x + e.col * f.cw; if (x < minX) minX = x; if (x > maxX) maxX = x; }
    if (minX < 1e9) {
      if (maxX > FW - 34 && f.dir > 0) { f.dir = -1; f.down = L.step; f.x -= maxX - (FW - 34); }
      else if (minX < 34 && f.dir < 0) { f.dir = 1; f.down = L.step; f.x += 34 - minX; }
    }
  }
  placeFormation(g, dt);
  // lowest enemy reaches player line -> invaded
  for (const e of alive) {
    if (e.mode === 'form' && e.y + 26 > PLAYER_Y - 24) { lose(g, 'invaded'); return; }
    if (e.mode === 'form' && e.y > FH - 230) eraseShieldRect(g, e.x - 26, e.y - 24, e.x + 26, e.y + 26);
  }
  // firing
  g.fireT -= dt;
  if (g.fireT <= 0 && g.state === 'play') {
    g.fireT = L.fireInt * rr(0.5, 1.4);
    if (g.ebul.length < L.maxBullets) {
      // bottom-most enemy of each column
      const cols = {};
      for (const e of alive) { if (e.mode !== 'form') continue; const k = e.col; if (!cols[k] || cols[k].y < e.y) cols[k] = e; }
      const shooters = Object.values(cols);
      if (shooters.length) {
        // bias toward player column
        shooters.sort((a, b) => Math.abs(a.x - g.player.x) - Math.abs(b.x - g.player.x));
        const pick = rnd() < 0.45 ? shooters[0] : shooters[ri(0, shooters.length - 1)];
        enemyFire(g, pick);
      }
    }
  }
  // divers
  if (L.diveRate > 0 && g.state === 'play' && rnd() < L.diveRate * dt * (1 + (1 - frac))) {
    const cands = alive.filter(e => e.mode === 'form');
    if (cands.length > 3 && g.enemies.filter(e => e.alive && e.mode !== 'form').length < 1 + Math.floor(L.d * 3)) {
      const e = cands[ri(0, cands.length - 1)];
      e.mode = 'dive'; e.t = 0; e.vx = 0; e.vy = -60; e.shot = false;
      Snd.sfx('dive');
    }
  }
}
function enemyFire(g, e) {
  const L = g.L, sp = L.bulletSpeed;
  if (e.type === 2 && rnd() < L.aimChance) {
    const v = aimAt(g, e.x, e.y + 18, sp);
    if (v.vy < sp * 0.45) { v.vy = sp * 0.45; }
    spawnEnemyBullet(g, e.x, e.y + 18, v.vx, v.vy, 'aim');
    if (L.w >= 7 && rnd() < 0.4) { const v2 = aimAt(g, e.x, e.y + 18, sp, 14), v3 = aimAt(g, e.x, e.y + 18, sp, -14); spawnEnemyBullet(g, e.x, e.y + 18, v2.vx, v2.vy, 'aim'); spawnEnemyBullet(g, e.x, e.y + 18, v3.vx, v3.vy, 'aim'); }
  } else {
    spawnEnemyBullet(g, e.x, e.y + 18, 0, sp * (e.type === 1 ? 0.85 : 1), e.type === 1 ? 'big' : 'n');
  }
}

function updateEnemies(g, dt) {
  const L = g.L;
  for (const e of g.enemies) {
    if (!e.alive) continue;
    e.t += dt; if (e.flash > 0) e.flash -= dt * 5;
    if (e.mode === 'dive') {
      const p = g.player;
      e.vy = Math.min(e.vy + 420 * dt, 210 + 130 * L.d);
      const want = clamp((p.x - e.x) * 1.3, -170, 170);
      e.vx = lerp(e.vx, e.y < PLAYER_Y - 120 ? want : e.vx, 1 - Math.pow(0.1, dt));
      e.x = clamp(e.x + e.vx * dt, 20, FW - 20); e.y += e.vy * dt;
      if (!e.shot && e.y > 380 && e.y < 520) { e.shot = true; const v = aimAt(g, e.x, e.y, L.bulletSpeed); if (v.vy > 60) spawnEnemyBullet(g, e.x, e.y + 16, v.vx, v.vy, 'aim'); }
      if (e.y > FH - 240 && e.y < FH - 140) eraseShieldRect(g, e.x - 18, e.y - 18, e.x + 18, e.y + 18);
      if (e.y > FH + 40) { e.mode = 'return'; e.y = -50; e.x = rr(80, FW - 80); }
    } else if (e.mode === 'return') {
      const tp = formPos(g, e);
      const dx = tp.x - e.x, dy = tp.y - e.y, d = Math.hypot(dx, dy);
      const sp = 280 * dt;
      if (d < sp) { e.mode = 'form'; e.x = tp.x; e.y = tp.y; }
      else { e.x += dx / d * sp; e.y += dy / d * sp; }
    } else if (e.mode === 'minion') {
      // boss helpers: fly to slot, hover, sometimes dive
      e.slotX += e.vx * dt; if (e.slotX < 60 || e.slotX > FW - 60) e.vx *= -1;
      const tx = e.slotX + Math.sin(e.t * 2) * 20, ty = e.slotY + Math.sin(e.t * 3) * 8;
      e.x = lerp(e.x, tx, 1 - Math.pow(0.02, dt)); e.y = lerp(e.y, ty, 1 - Math.pow(0.02, dt));
      e.fire -= dt;
      if (e.fire <= 0) { e.fire = rr(2.2, 4.5) * (1.2 - L.d * 0.5); if (g.ebul.length < L.maxBullets + 6) spawnEnemyBullet(g, e.x, e.y + 16, 0, L.bulletSpeed * 0.9, 'n'); }
      if (e.t > e.diveAt) { e.mode = 'dive'; e.vx = 0; e.vy = -40; e.shot = false; e.minion = true; }
    }
    if (e.mode === 'dive' && e.minion && e.y > FH + 30) { e.alive = false; }
  }
  if (g.boss) g.enemies = g.enemies.filter(e => e.alive);
}

function updateBonus(g, dt) {
  if (g.boss) return;
  if (!g.bonus) {
    g.bonusT -= dt;
    if (g.bonusT <= 0 && g.state === 'play' && g.enemies.filter(e => e.alive).length > 4) {
      const dir = rnd() < 0.5 ? 1 : -1;
      g.bonus = { x: dir > 0 ? -60 : FW + 60, y: 78, dir, t: 0, pts: [100, 150, 200, 300][ri(0, 3)] };
      g.bonusT = rr(18, 28);
    }
  } else {
    const b = g.bonus; b.t += dt; b.x += b.dir * 135 * dt;
    g.noteT -= dt;
    if (g.noteT <= 0) { g.noteT = 0.14; const mel = [784, 988, 1175, 988, 1319, 1175, 988, 880]; Snd.sfx('bonusNote', mel[g.noteI++ % mel.length]); }
    if (b.x < -90 || b.x > FW + 90) g.bonus = null;
  }
}

function bossPhase(b) { const f = b.hp / b.maxhp; return f > 0.66 ? 0 : f > 0.33 ? 1 : 2; }
function updateBoss(g, dt) {
  const b = g.boss, L = g.L, w = b.idx;
  if (b.dying > 0) return;
  b.t += dt; if (b.flash > 0) b.flash -= dt * 4;
  const ph = bossPhase(b);
  if (ph !== b.phase) { b.phase = ph; b.atkT = Math.min(b.atkT, 0.8); g.flashScreen = 0.6; Snd.sfx('warn'); }
  // movement
  const amp = 220 + w * 6, spx = 0.33 + w * 0.02 + ph * 0.08;
  if (b.dash) {
    b.dash.t += dt;
    const k = b.dash.t;
    if (k < 0.7) { b.x = lerp(b.x, b.dash.x, 1 - Math.pow(0.01, dt)); b.y = b.baseY - 30 * Math.sin(k / 0.7 * Math.PI); }
    else if (k < 1.5) { b.y = lerp(b.baseY, 470, Math.sin((k - 0.7) / 0.8 * Math.PI / 2)); }
    else if (k < 2.6) { b.y = lerp(470, b.baseY, (k - 1.5) / 1.1); }
    else { b.dash = null; b.t0 = b.t; }
    if (b.y > FH - 330) eraseShieldRect(g, b.x - 60, b.y - 40, b.x + 60, b.y + 90);
  } else {
    const tx = FW / 2 + Math.sin(b.t * spx) * amp;
    b.x = lerp(b.x, tx, 1 - Math.pow(0.08, dt));
    b.y = lerp(b.y, b.baseY + Math.sin(b.t * 1.4) * 18, 1 - Math.pow(0.08, dt));
  }
  if (w >= 8) b.rot += dt * (0.5 + ph * 0.3);
  // attack queue (bullets spread over time)
  for (let i = b.queue.length - 1; i >= 0; i--) {
    const q = b.queue[i]; q.t -= dt;
    if (q.t <= 0) { q.fn(); b.queue.splice(i, 1); }
  }
  b.atkT -= dt;
  if (b.atkT <= 0 && !b.dash) {
    const list = BOSS_ATTACKS[w];
    const atk = list[b.atkI++ % list.length];
    bossAttack(g, atk);
    b.atkT = (2.3 - L.d * 0.9) * (1 - ph * 0.18) + rr(-0.2, 0.3);
  }
  // pods (space bosses)
  if (b.pods) {
    b.podT -= dt;
    if (b.podT <= 0) {
      b.podT = 1.6 - ph * 0.3;
      const k = ri(0, b.pods - 1); const pp = podPos(b, k);
      const v = aimAt(g, pp.x, pp.y, L.bulletSpeed * 0.85);
      if (v.vy > 40) spawnEnemyBullet(g, pp.x, pp.y, v.vx, v.vy, 'aim');
    }
  }
}
function podPos(b, k) {
  const a = b.t * 1.1 + k * TAU / b.pods;
  return { x: b.x + Math.cos(a) * 150, y: b.y + Math.sin(a) * 70 };
}
function bossAttack(g, atk) {
  const b = g.boss, L = g.L, ph = b.phase, sp = 170 + 120 * L.d;
  const mouth = () => ({ x: b.x, y: b.y + 60 });
  Snd.sfx('bossShot');
  switch (atk) {
    case 'aimed': {
      const n = 3 + ph + (L.w >= 4 ? 1 : 0);
      for (let i = 0; i < n; i++) b.queue.push({ t: i * 0.18, fn: () => { const m = mouth(); const v = aimAt(g, m.x, m.y, sp * 1.1); spawnEnemyBullet(g, m.x, m.y, v.vx, Math.max(v.vy, 60), 'aim'); } });
      break;
    }
    case 'spread': {
      const n = 5 + ph * 2 + Math.floor(L.w / 3);
      const m = mouth(); const arc = 70 + L.w * 3;
      for (let i = 0; i < n; i++) { const a = Math.PI / 2 + (i / (n - 1) - 0.5) * arc * Math.PI / 180; spawnEnemyBullet(g, m.x, m.y, Math.cos(a) * sp, Math.sin(a) * sp, 'big'); }
      break;
    }
    case 'rain': {
      const n = Math.round(6 + ph * 2 + L.w * 0.6);
      const gap = rr(80, FW - 80);
      for (let i = 0; i < n; i++) b.queue.push({ t: i * 0.09, fn: () => { let x = rr(30, FW - 30); if (Math.abs(x - gap) < 70) x = (x + 160) % FW; spawnEnemyBullet(g, x, 60, 0, sp * 0.8, 'n'); } });
      break;
    }
    case 'spiral': {
      const n = 16 + ph * 6;
      for (let i = 0; i < n; i++) b.queue.push({ t: i * 0.06, fn: () => { const a = Math.PI * 0.15 + (i / n) * Math.PI * 0.7 * (i % 2 ? 1 : 1); const aa = Math.PI / 2 + Math.sin(i * 0.5) * 1.0; spawnEnemyBullet(g, b.x, b.y + 40, Math.cos(aa) * sp, Math.sin(aa) * sp, 'n'); } });
      break;
    }
    case 'ring': {
      const n = 12 + ph * 4;
      const off = rnd() * TAU;
      for (let i = 0; i < n; i++) { const a = off + i / n * TAU; const vy = Math.sin(a) * sp * 0.8; if (vy > 30) spawnEnemyBullet(g, b.x, b.y, Math.cos(a) * sp * 0.8, vy, 'big'); }
      break;
    }
    case 'dash': {
      b.dash = { t: 0, x: clamp(g.player.x, 140, FW - 140) };
      Snd.sfx('warn');
      break;
    }
    case 'summon': {
      const cur = g.enemies.filter(e => e.alive).length;
      const n = Math.min(2 + ph + Math.floor(L.w / 4), 7 - cur);
      for (let i = 0; i < n; i++) {
        const e = makeEnemy(g, rnd() < 0.3 ? 1 : 0, 0, 0);
        e.hp = e.maxhp = 1; e.mode = 'minion'; e.x = b.x; e.y = b.y;
        e.slotX = clamp(b.x + (i - (n - 1) / 2) * 70, 60, FW - 60); e.slotY = 360 + (i % 2) * 40; e.vx = (rnd() < 0.5 ? -1 : 1) * 40;
        e.fire = rr(1.5, 3.5); e.diveAt = rr(4, 9);
        g.enemies.push(e);
      }
      break;
    }
  }
}
function bossDie(g) {
  const b = g.boss; b.dying = 0.001; b.hp = 0;
  for (const e of g.enemies) if (e.alive) { e.alive = false; addFx(g, e.x, e.y, 0.8); }
  g.ebul.length = 0;
  addScore(g, 1000 + L_bonus(g));
  floatText(g, b.x, b.y, '+' + (1000 + L_bonus(g)), '#ffe066');
  g.kills++;
  Snd.sfx('bigBoom');
  g.shake = 10;
  win(g);
}
function L_bonus(g) { return g.L.w * 300; }
function updateBossDeath(g, dt) {
  const b = g.boss; b.dying += dt;
  if (Math.floor(b.dying * 12) !== Math.floor((b.dying - dt) * 12) && b.dying < 2) {
    addFx(g, b.x + rr(-90, 90), b.y + rr(-80, 80), rr(0.7, 1.4)); burst(g, b.x + rr(-60, 60), b.y + rr(-60, 60), g.world.bullet, 6, 220);
    if (!headless && rnd() < 0.5) Snd.sfx('kill', ri(0, 4));
  }
}

function updateBullets(g, dt) {
  for (const b of g.pbul) b.y += b.vy * dt;
  g.pbul = g.pbul.filter(b => b.y > -30 && !b.dead);
  for (const b of g.ebul) { b.x += b.vx * dt; b.y += b.vy * dt; b.t += dt; b.age += dt; }
  g.ebul = g.ebul.filter(b => b.y < FH + 20 && b.x > -20 && b.x < FW + 20 && b.y > -40 && !b.dead);
}
function dropPowerup(g, x, y, force) {
  if (!force && (g.pups.length > 0 || rnd() > 0.07)) return;
  const p = g.player;
  const pool = [['double', 30], ['rapid', 30], ['shield', 24]];
  if (g.lives < 4) pool.push(['life', g.lives < 3 ? 16 : 7]);
  let tot = pool.reduce((s, a) => s + a[1], 0), r = rnd() * tot, k = pool[0][0];
  for (const a of pool) { if ((r -= a[1]) <= 0) { k = a[0]; break; } }
  g.pups.push({ x, y, k, vy: 115, t: 0 });
}
function updatePowerups(g, dt) {
  const p = g.player;
  for (const u of g.pups) {
    u.y += u.vy * dt; u.t += dt;
    if (Math.abs(u.x - p.x) < 40 && Math.abs(u.y - p.y) < 40 && p.dead <= 0) {
      u.dead = true;
      if (u.k === 'double') p.double = 14;
      if (u.k === 'rapid') p.rapid = 14;
      if (u.k === 'shield') p.shield = 22;
      if (u.k === 'life') { g.lives = Math.min(5, g.lives + 1); }
      Snd.sfx(u.k === 'life' ? 'life' : 'power');
      floatText(g, p.x, p.y - 50, T('pu_' + u.k), '#fff');
      burst(g, p.x, p.y, '#ffffff', 10, 160);
    }
  }
  g.pups = g.pups.filter(u => !u.dead && u.y < FH + 30);
}

function hurtPlayer(g, cause) {
  const p = g.player;
  if (p.inv > 0 || p.dead > 0) return;
  (g.hitLog = g.hitLog || []).push(cause + '@' + Math.round(g.playT));
  if (p.shield > 0) { p.shield = 0; p.inv = 1.0; Snd.sfx('shieldPop'); burst(g, p.x, p.y, '#7fe6ff', 18, 240); return; }
  g.lives--; g.hits++;
  p.inv = 2.2; p.dead = 0.8; p.double = 0; p.rapid = 0;
  addFx(g, p.x, p.y, 1.2);
  burst(g, p.x, p.y, '#7fe6ff', 22, 260);
  g.shake = 9; g.flashScreen = 0.5;
  Snd.sfx('playerHit');
  // clear nearby bullets to be fair
  for (const b of g.ebul) if (Math.abs(b.y - p.y) < 220) b.dead = true;
}

function collide(g) {
  const p = g.player;
  // player bullets
  for (const b of g.pbul) {
    if (b.dead) continue;
    if (shieldHit(g, b.x, b.y - 8, 3, 2.0)) { b.dead = true; Snd.sfx('shieldHit'); continue; }
    // enemies
    for (const e of g.enemies) {
      if (!e.alive) continue;
      if (Math.abs(b.x - e.x) < 27 && Math.abs(b.y - e.y) < 25) {
        b.dead = true; e.hp--; e.flash = 1;
        if (e.hp <= 0) killEnemy(g, e);
        else { Snd.sfx('hit'); burst(g, b.x, b.y, '#fff', 4, 120); }
        break;
      }
    }
    if (b.dead) continue;
    // bonus ship
    if (g.bonus && Math.abs(b.x - g.bonus.x) < 46 && Math.abs(b.y - g.bonus.y) < 22) {
      b.dead = true;
      const pts = g.bonus.pts * (1 + g.L.w * 0.2);
      addScore(g, pts); floatText(g, g.bonus.x, g.bonus.y, '+' + Math.round(pts), '#ffe066');
      addFx(g, g.bonus.x, g.bonus.y, 1.0); burst(g, g.bonus.x, g.bonus.y, '#ffd34d', 18, 240);
      dropPowerup(g, g.bonus.x, g.bonus.y, true);
      Snd.sfx('bonusKill'); g.bonus = null; continue;
    }
    // boss
    const bs = g.boss;
    if (bs && bs.dying === 0 && g.state === 'play') {
      const hw = sprW('boss' + bs.idx, bs.scale) * 0.42, hh = sprH('boss' + bs.idx, bs.scale) * 0.45;
      if (Math.abs(b.x - bs.x) < hw && Math.abs(b.y - bs.y) < hh) {
        b.dead = true; bs.hp--; bs.flash = 1; addScore(g, 5);
        burst(g, b.x, b.y, '#fff', 3, 120);
        Snd.sfx('bossHit');
      }
    }
    // enemy bullets can be shot (not in boss fights)
    if (!g.boss) for (const eb of g.ebul) {
      if (!eb.dead && Math.abs(eb.x - b.x) < eb.r + 3 && Math.abs(eb.y - b.y) < eb.r + 10) {
        eb.dead = true; b.dead = true; burst(g, eb.x, eb.y, g.world.bullet, 5, 100); addScore(g, 2); break;
      }
    }
  }
  // enemy bullets
  for (const eb of g.ebul) {
    if (eb.dead) continue;
    if (eb.y > FH - 240 && shieldHit(g, eb.x, eb.y + eb.r * 0.5, eb.r * 0.6, eb.kind === 'big' ? 3.2 : 2.5)) { eb.dead = true; Snd.sfx('shieldHit'); continue; }
    if (p.dead <= 0 && Math.abs(eb.x - p.x) < 18 + eb.r * 0.6 && Math.abs(eb.y - (p.y + 4)) < 16 + eb.r * 0.6) {
      eb.dead = true; hurtPlayer(g, 'bullet-' + eb.kind + (eb.minion ? '' : ''));
    }
  }
  // divers vs player
  for (const e of g.enemies) {
    if (!e.alive || e.mode === 'form') continue;
    if (Math.abs(e.x - p.x) < 34 && Math.abs(e.y - p.y) < 30 && p.dead <= 0 && p.inv <= 0) { killEnemy(g, e); hurtPlayer(g, e.minion ? 'minion' : 'diver'); }
  }
  // dashing boss vs player
  if (g.boss && g.boss.dash && Math.abs(g.boss.x - p.x) < 70 && g.boss.y + 80 > p.y - 20) hurtPlayer(g, 'dash');
}
function killEnemy(g, e) {
  e.alive = false;
  g.kills++;
  const pts = [10, 20, 30][e.type] * (1 + g.L.w * 0.2) * (e.mode !== 'form' && !e.minion ? 2 : 1);
  addScore(g, pts);
  addFx(g, e.x, e.y, 0.62);
  burst(g, e.x, e.y, g.world.shield[0], 8, 200);
  if (pts >= 40) floatText(g, e.x, e.y - 10, '+' + Math.round(pts), '#fff');
  Snd.sfx('kill', e.type + (e.row || 0));
  dropPowerup(g, e.x, e.y, false);
}

function win(g) {
  g.state = 'clear'; g.stateT = 0;
  const p = g.player;
  const clearBonus = 300 + g.lives * 250 + Math.max(0, Math.round((g.boss ? 150 : 90) - g.playT)) * 6;
  addScore(g, clearBonus);
  g.clearBonus = clearBonus;
  g.ebul.length = 0;
  if (!g.boss) Snd.sfx('win');
  else setTimeout(() => Snd.sfx('win'), 900);
}
function lose(g, why) {
  if (g.state !== 'play') return;
  g.state = 'over'; g.stateT = 0; g.why = why;
  if (why === 'invaded') { addFx(g, g.player.x, g.player.y, 1.3); g.player.dead = 99; g.shake = 10; }
  Snd.sfx('lose');
}
function starsFor(g) { return g.hits === 0 ? 3 : g.hits === 1 ? 2 : 1; }

function updateAmb(g, dt) {
  for (let i = 0; i < g.amb.length; i++) {
    const a = g.amb[i]; a.t += dt;
    a.x += (a.vx + (a.k === 'snow' || a.k === 'leaf' || a.k === 'petal' ? Math.sin(a.t * 1.5) * 18 : 0)) * dt; a.y += a.vy * dt;
    if (a.y > FH + 20 || a.y < -30 || a.x < -30 || a.x > FW + 30) g.amb[i] = newAmb(g, false);
  }
}
function updateFx(g, dt) {
  for (const f of g.fx) f.t += dt;
  g.fx = g.fx.filter(f => f.t < 0.5);
  for (const p of g.parts) { p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.96; p.vy = p.vy * 0.96 + 200 * dt; }
  g.parts = g.parts.filter(p => p.t < p.life);
  for (const f of g.floats) { f.t += dt; f.y -= 40 * dt; }
  g.floats = g.floats.filter(f => f.t < 1.1);
}

// ---------------------------------------------------------------- render
function drawBg(g, w) {
  const bg = IMG['bg' + w];
  const s = FS * DPR;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = WORLDS[w].dark; ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (bg) {
    // bg is 1200x900, centred on the field, repeated sideways
    const x0 = (FX - 200 * FS) * DPR, y0 = FY * DPR, bw = 1200 * s, bh = 900 * s;
    for (let k = -2; k <= 2; k++) {
      const x = x0 + k * bw;
      if (x > canvas.width || x + bw < 0) continue;
      if (k % 2) { ctx.save(); ctx.translate(x + bw, y0); ctx.scale(-1, 1); ctx.drawImage(bg, 0, 0, bw, bh); ctx.restore(); }
      else ctx.drawImage(bg, x, y0, bw, bh);
    }
    // stretch the top/bottom edge rows if the screen is taller than the field
    if (y0 > 0) { ctx.drawImage(bg, 0, 0, 1200, 2, x0 - bw * 2, 0, bw * 5, y0 + 1); }
    if (y0 + bh < canvas.height) { ctx.drawImage(bg, 0, 897, 1200, 3, x0 - bw * 2, y0 + bh - 1, bw * 5, canvas.height - y0 - bh + 1); }
  }
}
function fieldTransform(shx, shy) {
  ctx.setTransform(FS * DPR, 0, 0, FS * DPR, (FX + (shx || 0) * FS) * DPR, (FY + (shy || 0) * FS) * DPR);
}
function drawShield(g, s) {
  if (!s.cv || s.dirty) {
    if (!s.cv) { s.cv = document.createElement('canvas'); s.cv.width = s.cols * s.cs * 2; s.cv.height = s.rows * s.cs * 2; }
    const c = s.cv.getContext('2d');
    c.clearRect(0, 0, s.cv.width, s.cv.height);
    const [c1, c2] = g.world.shield;
    for (let r = 0; r < s.rows; r++) for (let col = 0; col < s.cols; col++) {
      if (!s.cells[r * s.cols + col]) continue;
      const x = col * s.cs * 2, y = r * s.cs * 2, z = s.cs * 2;
      c.fillStyle = r > s.rows * 0.55 ? c2 : c1;
      c.fillRect(x, y, z + 0.5, z + 0.5);
      // top highlight / edges
      const up = r === 0 || !s.cells[(r - 1) * s.cols + col];
      if (up) { c.fillStyle = 'rgba(255,255,255,0.55)'; c.fillRect(x, y, z, 2); }
      const dn = r === s.rows - 1 || !s.cells[(r + 1) * s.cols + col];
      if (dn) { c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(x, y + z - 2, z, 2); }
    }
    s.dirty = false;
  }
  ctx.drawImage(s.cv, s.x, s.y, s.cols * s.cs, s.rows * s.cs);
}
function drawEnemyBullet(g, b) {
  const col = g.world.bullet;
  ctx.save();
  ctx.translate(b.x, b.y);
  const r = b.r * (1 + Math.sin(b.t * 18) * 0.08);
  ctx.globalAlpha = 0.35; ctx.fillStyle = col;
  ctx.beginPath(); ctx.ellipse(0, -r * 0.8, r * 0.8, r * 2.0, Math.atan2(-b.vx, b.vy), 0, TAU); ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-r * 0.25, -r * 0.25, r * 0.45, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.stroke();
  ctx.restore();
}
const PU_COL = { double: '#ff8a3d', rapid: '#ffd23d', shield: '#3dc8ff', life: '#ff4f7a' };
function drawPuIcon(k, x, y, r, t) {
  ctx.save(); ctx.translate(x, y);
  ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.arc(2, 3, r, 0, TAU); ctx.fill();
  ctx.fillStyle = PU_COL[k]; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.arc(0, -r * 0.15, r * 0.8, Math.PI * 1.1, Math.PI * 1.9); ctx.fill();
  ctx.strokeStyle = '#fff'; ctx.lineWidth = r * 0.14; ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.stroke();
  ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff'; ctx.lineWidth = r * 0.16; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const u = r / 10;
  if (k === 'double') { for (const dx of [-3.2, 3.2]) { ctx.beginPath(); ctx.moveTo(dx * u, 5 * u); ctx.lineTo(dx * u, -5 * u); ctx.stroke(); ctx.beginPath(); ctx.moveTo((dx - 2.4) * u, -2.4 * u); ctx.lineTo(dx * u, -5.4 * u); ctx.lineTo((dx + 2.4) * u, -2.4 * u); ctx.stroke(); } }
  if (k === 'rapid') { ctx.beginPath(); ctx.moveTo(1.5 * u, -6.5 * u); ctx.lineTo(-3.5 * u, 1 * u); ctx.lineTo(0, 1 * u); ctx.lineTo(-1.5 * u, 6.5 * u); ctx.lineTo(3.5 * u, -1 * u); ctx.lineTo(0, -1 * u); ctx.closePath(); ctx.fill(); }
  if (k === 'shield') { ctx.beginPath(); ctx.moveTo(0, -6 * u); ctx.lineTo(5 * u, -3.5 * u); ctx.quadraticCurveTo(5 * u, 4 * u, 0, 6.5 * u); ctx.quadraticCurveTo(-5 * u, 4 * u, -5 * u, -3.5 * u); ctx.closePath(); ctx.fill(); }
  if (k === 'life') heartPath(0, 0.5 * u, 5.6 * u), ctx.fill();
  ctx.restore();
}
function heartPath(x, y, s) {
  ctx.beginPath();
  ctx.moveTo(x, y + s * 0.9);
  ctx.bezierCurveTo(x - s * 1.4, y - s * 0.1, x - s * 0.8, y - s * 1.2, x, y - s * 0.45);
  ctx.bezierCurveTo(x + s * 0.8, y - s * 1.2, x + s * 1.4, y - s * 0.1, x, y + s * 0.9);
  ctx.closePath();
}
function starPath(x, y, r) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5; const rr2 = i % 2 ? r * 0.45 : r; ctx[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
  ctx.closePath();
}
function txt(s, x, y, size, col, align, stroke) {
  ctx.font = `700 ${size}px Fredoka, "Baloo 2", system-ui, sans-serif`;
  ctx.textAlign = align || 'left'; ctx.textBaseline = 'middle';
  if (stroke !== false) { ctx.lineWidth = size * 0.22; ctx.strokeStyle = 'rgba(20,16,40,0.75)'; ctx.lineJoin = 'round'; ctx.strokeText(s, x, y); }
  ctx.fillStyle = col || '#fff'; ctx.fillText(s, x, y);
}

function drawAmb(g) {
  for (const a of g.amb) {
    ctx.save(); ctx.translate(a.x, a.y);
    switch (a.k) {
      case 'bubble': ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(0, 0, 3 * a.s + 1, 0, TAU); ctx.stroke(); break;
      case 'snow': ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.arc(0, 0, 2.2 * a.s, 0, TAU); ctx.fill(); break;
      case 'leaf': ctx.rotate(a.t * 2); ctx.fillStyle = 'rgba(232,115,46,0.8)'; ctx.beginPath(); ctx.ellipse(0, 0, 6 * a.s, 3 * a.s, 0, 0, TAU); ctx.fill(); break;
      case 'petal': ctx.rotate(a.t * 2); ctx.fillStyle = 'rgba(255,160,210,0.85)'; ctx.beginPath(); ctx.ellipse(0, 0, 5 * a.s, 2.6 * a.s, 0, 0, TAU); ctx.fill(); break;
      case 'ember': ctx.globalAlpha = 0.5 + 0.5 * Math.sin(a.t * 6); ctx.fillStyle = '#ffb347'; ctx.beginPath(); ctx.arc(0, 0, 2 * a.s, 0, TAU); ctx.fill(); break;
      case 'sand': ctx.fillStyle = 'rgba(255,240,200,0.6)'; ctx.fillRect(0, 0, 3 * a.s, 1.5); break;
      case 'pollen': ctx.globalAlpha = 0.6; ctx.fillStyle = '#fff7b0'; ctx.beginPath(); ctx.arc(0, 0, 1.8 * a.s, 0, TAU); ctx.fill(); break;
      default: ctx.globalAlpha = 0.3 + 0.7 * Math.abs(Math.sin(a.t * 2)); ctx.fillStyle = '#fff'; ctx.fillRect(-1, -1, 2.2 * a.s, 2.2 * a.s); break;
    }
    ctx.restore();
  }
}

function drawEnemy(g, e) {
  const kind = g.world.kind;
  const base = g.form ? g.form.es : 0.56;
  const o = { flash: g.L.w === 6 ? Math.max(e.flash, 0.22) : e.flash };
  const isFish = e.spr.startsWith('e2_');
  const isDrone = g.L.w >= 8;
  if (isFish) { o.flip = (e.mode === 'form' ? g.form.dir > 0 : e.vx > 0); o.rot = Math.sin(e.t * 6) * 0.06; }
  else if (isDrone) { o.rot = Math.sin(e.t * 2) * 0.12; }
  else {
    const sq = Math.sin(e.t * 5);
    o.sx = 1 + sq * 0.05; o.sy = 1 - sq * 0.05; o.rot = Math.sin(e.t * 2.5) * 0.06;
  }
  if (e.mode === 'dive') o.rot = (o.rot || 0) + clamp(e.vx / 400, -0.5, 0.5);
  spr(e.spr, e.x, e.y + (isDrone ? Math.sin(e.t * 3) * 2 : 0), base, o);
  if (e.maxhp > 1 && e.hp < e.maxhp) {
    ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(e.x - 16, e.y + 29, 32, 4);
    ctx.fillStyle = '#ffe066'; ctx.fillRect(e.x - 16, e.y + 29, 32 * e.hp / e.maxhp, 4);
  }
}

function render(g) {
  const w = g ? g.L.w : (menuWorld || 0);
  drawBg(g, w);
  if (!g) return;
  const shx = g.shake ? rr(-g.shake, g.shake) : 0, shy = g.shake ? rr(-g.shake, g.shake) : 0;
  // dim area outside the field slightly
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = 'rgba(0,0,0,0.28)';
  const fx0 = FX * DPR, fy0 = FY * DPR, fw = FW * FS * DPR, fh = FH * FS * DPR;
  ctx.fillRect(0, 0, fx0, canvas.height); ctx.fillRect(fx0 + fw, 0, canvas.width - fx0 - fw, canvas.height);
  ctx.fillRect(fx0, 0, fw, fy0); ctx.fillRect(fx0, fy0 + fh, fw, canvas.height - fy0 - fh);
  fieldTransform(shx, shy);
  ctx.save();
  ctx.beginPath(); ctx.rect(-20, -20, FW + 40, FH + 40); ctx.clip();
  drawAmb(g);
  for (const s of g.shields) drawShield(g, s);
  // power-ups
  for (const u of g.pups) drawPuIcon(u.k, u.x, u.y + Math.sin(u.t * 5) * 3, 17, u.t);
  // boss
  const b = g.boss;
  if (b && (b.dying < 2.2)) {
    if (b.pods) for (let k = 0; k < b.pods; k++) { const pp = podPos(b, k); spr('pod' + (b.idx - 8), pp.x, pp.y, 0.55, { rot: b.rot * 2 }); }
    const alpha = b.dying > 0 ? Math.max(0, 1 - b.dying / 2.2) : 1;
    const wob = b.dying > 0 ? rr(-6, 6) : 0;
    const sq = Math.sin(b.t * 3) * 0.03;
    spr('boss' + b.idx, b.x + wob, b.y, b.scale, { flash: b.flash, alpha, rot: b.idx >= 8 ? b.rot : Math.sin(b.t * 1.7) * 0.05, sx: 1 + sq, sy: 1 - sq });
    if (b.dash && b.dash.t < 0.7) { ctx.globalAlpha = 0.5 + 0.5 * Math.sin(g.t * 30); txt('!', b.x, b.y + 130, 54, '#ff4f6d', 'center'); ctx.globalAlpha = 1; }
  }
  for (const e of g.enemies) if (e.alive) drawEnemy(g, e);
  if (g.bonus) spr('bonus', g.bonus.x, g.bonus.y + Math.sin(g.bonus.t * 5) * 4, 0.52, { rot: Math.sin(g.bonus.t * 3) * 0.08 });
  // player bullets
  for (const pb of g.pbul) spr('beam', pb.x, pb.y, 0.9);
  // player
  const p = g.player;
  if (!(g.state === 'over' && g.why === 'invaded')) {
    const vis = p.dead > 0 ? false : !(p.inv > 0 && Math.floor(g.t * 14) % 2 === 0);
    if (vis) {
      // engine flame
      const fl = 8 + Math.sin(g.t * 40) * 3;
      ctx.fillStyle = 'rgba(255,190,80,0.9)'; ctx.beginPath(); ctx.moveTo(p.x - 7, p.y + 22); ctx.lineTo(p.x + 7, p.y + 22); ctx.lineTo(p.x, p.y + 22 + fl * 1.6); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,220,0.9)'; ctx.beginPath(); ctx.moveTo(p.x - 3.5, p.y + 22); ctx.lineTo(p.x + 3.5, p.y + 22); ctx.lineTo(p.x, p.y + 22 + fl); ctx.closePath(); ctx.fill();
      spr('player', p.x, p.y, 0.56, { rot: p.tilt });
      if (p.shield > 0) {
        const blink = p.shield < 3 && Math.floor(g.t * 8) % 2 === 0;
        if (!blink) { ctx.strokeStyle = 'rgba(127,230,255,0.85)'; ctx.lineWidth = 3; ctx.fillStyle = 'rgba(127,230,255,0.15)'; ctx.beginPath(); ctx.arc(p.x, p.y, 40 + Math.sin(g.t * 6) * 2, 0, TAU); ctx.fill(); ctx.stroke(); }
      }
    }
  }
  for (const eb of g.ebul) drawEnemyBullet(g, eb);
  // fx
  for (const f of g.fx) {
    const k = Math.min(8, Math.floor(f.t / 0.5 * 9));
    spr('ex' + k, f.x, f.y, 0.7 * f.s, { alpha: 1 - f.t / 0.6 });
  }
  for (const pa of g.parts) { ctx.globalAlpha = 1 - pa.t / pa.life; ctx.fillStyle = pa.col; ctx.beginPath(); ctx.arc(pa.x, pa.y, pa.r * (1 - pa.t / pa.life * 0.5), 0, TAU); ctx.fill(); }
  ctx.globalAlpha = 1;
  for (const f of g.floats) { ctx.globalAlpha = 1 - f.t / 1.1; txt(f.txt, f.x, f.y, 22, f.col, 'center'); }
  ctx.globalAlpha = 1;
  ctx.restore();
  // HUD
  fieldTransform(0, 0);
  drawHud(g);
  if (g.flashScreen > 0) { ctx.fillStyle = `rgba(255,255,255,${g.flashScreen * 0.35})`; ctx.fillRect(0, 0, FW, FH); }
  // banners
  if (g.state === 'intro') {
    const a = Math.min(1, g.stateT * 3, (2.2 - g.stateT) * 3);
    ctx.globalAlpha = Math.max(0, a);
    txt(T('level') + ' ' + g.n, FW / 2, FH * 0.42, 64, '#fff', 'center');
    txt(T('w' + g.L.w), FW / 2, FH * 0.42 + 58, 32, '#ffe066', 'center');
    if (g.boss) txt(T('bossIncoming') + ' ' + BOSS_NAMES[g.L.w], FW / 2, FH * 0.42 + 106, 34, '#ff6b7a', 'center');
    ctx.globalAlpha = 1;
  }
  if (g.state === 'clear' && g.stateT > 0.2 && screen === 'play') { txt(T('complete'), FW / 2, FH * 0.45, 58, '#ffe066', 'center'); }
  if (g.state === 'over' && g.stateT > 0.2 && screen === 'play') { txt(T('failed'), FW / 2, FH * 0.45, 58, '#ff6b7a', 'center'); }
}
function drawHud(g) {
  const k = FS < 0.62 ? 1.4 : 1;          // bigger HUD on small screens
  ctx.fillStyle = 'rgba(15,12,35,0.38)';
  roundRect(10, 10, FW - 20, 46 * k, 14); ctx.fill();
  const cy = 10 + 23 * k;
  txt(String(g.score).padStart(6, '0'), 24, cy, 26 * k, '#fff');
  txt(k > 1 ? T('level') + ' ' + g.n : T('level') + ' ' + g.n + ' · ' + T('w' + g.L.w), FW / 2 + (k > 1 ? -20 : 0), cy, 22 * k, '#fff', 'center');
  for (let i = 0; i < Math.max(3, g.lives); i++) {
    ctx.fillStyle = i < g.lives ? '#ff4f7a' : 'rgba(255,255,255,0.25)';
    heartPath(FW - 34 * k - i * 30 * k, cy + 1, 11 * k); ctx.fill();
    if (i < g.lives) { ctx.strokeStyle = 'rgba(20,16,40,0.7)'; ctx.lineWidth = 2; ctx.stroke(); }
  }
  // active power-ups
  const p = g.player; let x = 34;
  for (const k of ['double', 'rapid', 'shield']) {
    const v = p[k]; if (v <= 0) continue;
    const max = k === 'shield' ? 22 : 14;
    drawPuIcon(k, x, FH - 24, 13, 0);
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, FH - 24, 18, -Math.PI / 2, -Math.PI / 2 + TAU * v / max); ctx.stroke();
    x += 44;
  }
  // boss bar
  const b = g.boss;
  if (b && g.state !== 'intro') {
    const bw = 420, bx = (FW - bw) / 2, by = 66 + (k - 1) * 46;
    ctx.fillStyle = 'rgba(15,12,35,0.55)'; roundRect(bx - 4, by - 4, bw + 8, 22, 10); ctx.fill();
    const f = Math.max(0, b.hp / b.maxhp);
    const grd = ctx.createLinearGradient(bx, 0, bx + bw, 0); grd.addColorStop(0, '#ff4f6d'); grd.addColorStop(1, '#ffb347');
    ctx.fillStyle = grd; roundRect(bx, by, bw * f, 14, 7); ctx.fill();
    txt(BOSS_NAMES[b.idx], FW / 2, by + 30, 18, '#fff', 'center');
  }
}
function roundRect(x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

// ---------------------------------------------------------------- level flow
let menuWorld = 0;
function startLevel(n) {
  n = clamp(n | 0, 1, 50);
  lastLevel = n;
  G = newGame(n);
  setScreen('play');
  Snd.resume();
  Snd.startMusic(G.L.w, G.L.boss);
  if (G.L.boss) setTimeout(() => G && G.state === 'intro' && Snd.sfx('warn'), 300);
  resetInputs();
}
function finishLevel(g, won) {
  if (g.finished) return;
  g.finished = true;
  const duration = Math.max(1, Math.round(g.playT));
  const stars = won ? starsFor(g) : 0;
  const score = Math.min(g.score, 6000 + 900 * duration);
  g.result = { won, stars, score, kills: g.kills, duration };
  if (headless) return;
  let prev = save.levels[g.n] || { stars: 0, score: 0 };
  let localBest = false;
  if (won) {
    const nb = { stars: Math.max(prev.stars || 0, stars), score: Math.max(prev.score || 0, score) };
    localBest = score > (prev.score || 0);
    save.levels[g.n] = nb;
    persist();
  }
  post({ type: 'score', game: SLUG, mode: 'level', level: g.n, score, stars, completed: won, kills: g.kills, wave: 0, duration });
  showResult(g, prev, localBest);
  Snd.startMusic(g.L.w, false, true);
}

// ---------------------------------------------------------------- save / platform messages
function storageKey() { return SLUG + (user && user.id != null ? '-u' + user.id : '-guest'); }
function loadLocal() {
  try { const s = localStorage.getItem(storageKey()); return s ? JSON.parse(s) : null; } catch (e) { return null; }
}
function mergeSave(a) {
  if (!a || typeof a !== 'object') return;
  if (a.levels && typeof a.levels === 'object') {
    for (const k of Object.keys(a.levels)) {
      const n = +k; if (!(n >= 1 && n <= 50)) continue;
      const v = a.levels[k] || {}; const cur = save.levels[n] || { stars: 0, score: 0 };
      save.levels[n] = { stars: clamp(Math.max(cur.stars || 0, +v.stars || 0), 0, 3), score: Math.max(cur.score || 0, +v.score || 0) };
    }
  }
}
function persist() {
  const data = { levels: save.levels, music: save.music, sfx: save.sfx };
  try { localStorage.setItem(storageKey(), JSON.stringify(data)); } catch (e) { }
  post({ type: 'save', data });
}
function post(msg) {
  try { if (window.parent && window.parent !== window) window.parent.postMessage(msg, location.origin); } catch (e) { }
}
window.addEventListener('message', ev => {
  if (ev.origin !== location.origin || ev.source !== window.parent) return;
  const m = ev.data; if (!m || typeof m !== 'object') return;
  if (m.type === 'init') {
    if (m.lang && LANG[m.lang] && m.lang !== lang) { lang = m.lang; applyTexts(); }
    user = m.user && m.user.id != null ? m.user : null;
    save.levels = {};
    mergeSave(loadLocal());
    if (m.save) { mergeSave(m.save); if (typeof m.save.music === 'boolean') save.music = m.save.music; if (typeof m.save.sfx === 'boolean') save.sfx = m.save.sfx; }
    else { const l = loadLocal(); if (l && typeof l.music === 'boolean') save.music = l.music; }
    if (m.controls) setControls(m.controls);
    Snd.setMusic(save.music);
    try { localStorage.setItem(storageKey(), JSON.stringify({ levels: save.levels, music: save.music, sfx: save.sfx })); } catch (e) { }
    refreshMenus();
  } else if (m.type === 'controls') {
    setControls(m.controls);
  } else if (m.type === 'scoreResult') {
    showScoreResult(m);
  }
});
function setControls(c) {
  if (!c || typeof c !== 'object') return;
  if (c.keys && typeof c.keys === 'object') controls.keys = Object.assign({}, controls.keys, c.keys);
  if (typeof c.sensitivity === 'number') controls.sensitivity = clamp(c.sensitivity, 0.2, 3);
  if (typeof c.invertY === 'boolean') controls.invertY = c.invertY;
}

// ---------------------------------------------------------------- DOM / menus
const $ = id => document.getElementById(id);
function setScreen(s) {
  screen = s;
  for (const id of ['menu', 'levels', 'help', 'pause', 'result']) { const el = $(id); if (el) el.classList.toggle('show', id === s); }
  document.body.classList.toggle('playing', s === 'play');
  if (s === 'play' && document.activeElement && document.activeElement.blur) document.activeElement.blur();
  document.body.classList.toggle('inmenu', s !== 'play');
  if (s !== 'play' && document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { } }
}
function totalStars() { let t = 0; for (const k in save.levels) t += save.levels[k].stars || 0; return t; }
function applyTexts() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-t]').forEach(el => { el.textContent = T(el.getAttribute('data-t')); });
  refreshMenus();
}
function refreshMenus() {
  $('totalStars').textContent = totalStars() + ' / 150';
  $('musicBtn').textContent = T('music') + ': ' + T(save.music ? 'on' : 'off');
  $('pmusicBtn').textContent = T('music') + ': ' + T(save.music ? 'on' : 'off');
  buildLevelGrid();
}
function buildLevelGrid() {
  const wrap = $('levelGrid'); wrap.innerHTML = '';
  for (let w = 0; w < 10; w++) {
    const sec = document.createElement('div'); sec.className = 'world'; sec.style.setProperty('--wc', WORLDS[w].ui);
    const h = document.createElement('div'); h.className = 'wname';
    h.innerHTML = `<span class="wnum">${w + 1}</span>`; const sp = document.createElement('span'); sp.textContent = T('w' + w); h.appendChild(sp);
    sec.appendChild(h);
    const row = document.createElement('div'); row.className = 'lrow';
    for (let s = 0; s < 5; s++) {
      const n = w * 5 + s + 1;
      const b = document.createElement('button'); b.className = 'lvl' + (s === 4 ? ' boss' : ''); b.setAttribute('data-level', n);
      const st = (save.levels[n] && save.levels[n].stars) || 0;
      b.innerHTML = `<span class="ln">${s === 4 ? '☠' : n}</span><span class="ls">${'★'.repeat(st)}<i>${'★'.repeat(3 - st)}</i></span>`;
      b.title = (s === 4 ? T('boss') + ' – ' : '') + T('level') + ' ' + n;
      b.addEventListener('click', () => { Snd.resume(); Snd.sfx('click'); startLevel(n); });
      row.appendChild(b);
    }
    sec.appendChild(row); wrap.appendChild(sec);
  }
}
function nextUnplayed() { for (let n = 1; n <= 50; n++) if (!(save.levels[n] && save.levels[n].stars)) return n; return 1; }
function showResult(g, prev, localBest) {
  const r = g.result;
  $('resTitle').textContent = r.won ? T('complete') : T('failed');
  $('resTitle').className = r.won ? 'win' : 'lose';
  $('resSub').textContent = r.won ? (T('level') + ' ' + g.n + ' · ' + T('w' + g.L.w)) : (g.why === 'invaded' ? T('invaded') : T('outOfLives'));
  const starsEl = $('resStars'); starsEl.innerHTML = '';
  for (let i = 0; i < 3; i++) {
    const s = document.createElement('span'); s.textContent = '★'; s.className = 'st' + (i < r.stars ? ' on' : '');
    s.style.animationDelay = (0.25 + i * 0.3) + 's'; starsEl.appendChild(s);
    if (i < r.stars) setTimeout(() => Snd.sfx('star', [660, 880, 1175][i]), 250 + i * 300);
  }
  $('resScore').textContent = r.score;
  $('resBest').textContent = Math.max(r.score * (r.won ? 1 : 0), (save.levels[g.n] && save.levels[g.n].score) || 0) || '–';
  $('resKills').textContent = r.kills;
  $('resTime').textContent = Math.floor(r.duration / 60) + ':' + String(r.duration % 60).padStart(2, '0');
  $('resNew').style.display = r.won && localBest && prev.score > 0 ? '' : 'none';
  $('resServer').textContent = window.parent !== window ? T('scoreSending') : '';
  $('btnNext').style.display = r.won && g.n < 50 ? '' : 'none';
  setScreen('result');
  setTimeout(() => (r.won && g.n < 50 ? $('btnNext') : $('btnRetry')).focus({ preventScroll: true }), 50);
}
function showScoreResult(m) {
  const el = $('resServer'); if (!el) return;
  if (!m.ok) { el.textContent = T('scoreFail'); return; }
  const parts = [];
  if (m.guest) parts.push(T('guestNote'));
  else {
    parts.push(T('scoreOk'));
    if (m.newBest) parts.push(T('newBest'));
    if (m.rank) parts.push(T('rank') + ' ' + m.rank);
  }
  el.textContent = parts.join(' · ');
}
function togglePause() {
  if (screen === 'play' && G && !G.finished) { setScreen('pause'); Snd.suspend(true); }
  else if (screen === 'pause') resumeGame();
}
function resumeGame(lock) {
  setScreen('play'); Snd.suspend(false); resetInputs();
  if (lock && lastMouseMode) tryLock();
}
function toggleMusic() {
  save.music = !save.music; Snd.setMusic(save.music); persist(); refreshMenus();
}
function resetInputs() { keys.clear(); mouseBtn.clear(); touchBtn.left = touchBtn.right = touchBtn.fire = false; dragTouch = null; lockedDX = 0; }

// ---------------------------------------------------------------- events
let lastMouseMode = false;
function tryLock() {
  if (touchMode) return;
  try {
    const r = canvas.requestPointerLock && canvas.requestPointerLock();
    if (r && r.catch) r.catch(() => { });
  } catch (e) { }
}
window.addEventListener('keydown', e => {
  const c = e.code;
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(c) && screen === 'play') e.preventDefault();
  if (c === 'Escape' || c === 'KeyP') { if (screen === 'play' || screen === 'pause') { togglePause(); e.preventDefault(); return; } if (c === 'Escape' && (screen === 'levels' || screen === 'help')) { setScreen('menu'); return; } }
  if (c === 'KeyM' && !e.repeat) { toggleMusic(); return; }
  if (screen === 'play') {
    keys.add(c);
    if (ARROW_FIRE.includes(c) || ['primary', 'jump', 'forward'].some(a => controls.keys[a] === c)) fireLatch = true; if (['ArrowLeft', 'ArrowRight', controls.keys.left, controls.keys.right].includes(c)) mouseAbsX = null; }
  Snd.resume();
});
window.addEventListener('keyup', e => { keys.delete(e.code); if (screen === 'play' && e.code === 'Space') e.preventDefault(); });
window.addEventListener('blur', () => { resetInputs(); if (screen === 'play') togglePause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && screen === 'play') togglePause(); });
canvas.addEventListener('contextmenu', e => e.preventDefault());
canvas.addEventListener('pointerdown', e => {
  Snd.resume();
  if (e.pointerType === 'touch') {
    if (!touchMode) { touchMode = true; document.body.classList.add('touch'); resize(); }
    if (screen === 'play' && !dragTouch) dragTouch = { id: e.pointerId, lastX: e.clientX };
    return;
  }
  if (screen !== 'play') return;
  lastMouseMode = true;
  if (!pointerLocked) tryLock();
  mouseBtn.add('Mouse' + e.button);
  if (controls.keys.primary === 'Mouse' + e.button || controls.keys.jump === 'Mouse' + e.button) fireLatch = true;
  e.preventDefault();
});
window.addEventListener('pointerup', e => {
  if (dragTouch && e.pointerId === dragTouch.id) dragTouch = null;
  if (e.pointerType !== 'touch') mouseBtn.delete('Mouse' + e.button);
});
window.addEventListener('pointercancel', e => { if (dragTouch && e.pointerId === dragTouch.id) dragTouch = null; });
window.addEventListener('pointermove', e => {
  if (dragTouch && e.pointerId === dragTouch.id) {
    lockedDX += (e.clientX - dragTouch.lastX) / FS * 1.15; dragTouch.lastX = e.clientX; return;
  }
  if (e.pointerType === 'touch' || screen !== 'play') return;
  if (pointerLocked) { lockedDX += (e.movementX || 0) / FS * controls.sensitivity; }
  else if (lastMouseMode || e.buttons) {
    const fx = (e.clientX - FX) / FS;
    if (fx >= -40 && fx <= FW + 40) mouseAbsX = clamp(fx, 0, FW);
  }
});
canvas.addEventListener('mousemove', e => { if (screen === 'play' && !pointerLocked) lastMouseMode = true; });
document.addEventListener('pointerlockchange', () => {
  const was = pointerLocked;
  pointerLocked = document.pointerLockElement === canvas;
  if (pointerLocked) mouseAbsX = null;
  if (was && !pointerLocked && screen === 'play') togglePause();
});
// touch buttons
function bindHold(id, prop) {
  const el = $(id);
  const on = e => { e.preventDefault(); touchBtn[prop] = true; el.classList.add('down'); Snd.resume(); };
  const off = e => { touchBtn[prop] = false; el.classList.remove('down'); };
  el.addEventListener('pointerdown', on); el.addEventListener('pointerup', off); el.addEventListener('pointerleave', off); el.addEventListener('pointercancel', off);
  el.addEventListener('contextmenu', e => e.preventDefault());
}
window.addEventListener('touchstart', () => { if (!touchMode) { touchMode = true; document.body.classList.add('touch'); resize(); } }, { passive: true });

function wireUi() {
  $('btnPlay').addEventListener('click', () => { Snd.resume(); Snd.sfx('click'); startLevel(nextUnplayed()); });
  $('btnLevels').addEventListener('click', () => { Snd.resume(); Snd.sfx('click'); setScreen('levels'); });
  $('btnHelp').addEventListener('click', () => { Snd.resume(); Snd.sfx('click'); setScreen('help'); });
  $('musicBtn').addEventListener('click', () => { Snd.resume(); toggleMusic(); if (save.music) Snd.startMusic(menuWorld, false, true); });
  $('pmusicBtn').addEventListener('click', () => toggleMusic());
  document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => { Snd.sfx('click'); setScreen('menu'); }));
  $('btnResume').addEventListener('click', () => resumeGame(true));
  $('btnRestart').addEventListener('click', () => { Snd.suspend(false); startLevel(G ? G.n : lastLevel); });
  $('btnPauseLevels').addEventListener('click', () => { Snd.suspend(false); G = null; setScreen('levels'); Snd.startMusic(menuWorld, false, true); });
  $('btnNext').addEventListener('click', () => { Snd.sfx('click'); startLevel(lastLevel + 1); });
  $('btnRetry').addEventListener('click', () => { Snd.sfx('click'); startLevel(lastLevel); });
  $('btnResLevels').addEventListener('click', () => { Snd.sfx('click'); G = null; setScreen('levels'); });
  $('pauseBtn').addEventListener('click', e => { e.stopPropagation(); togglePause(); });
  bindHold('tLeft', 'left'); bindHold('tRight', 'right'); bindHold('tFire', 'fire');
  // power-up legend icons in help
  document.querySelectorAll('canvas[data-pu]').forEach(c => {
    const k = c.getAttribute('data-pu'); c.width = 64; c.height = 64;
    drawPuOn(c.getContext('2d'), k);
  });
}
function drawPuOn(x2, k) {
  const old = ctx; ctx = x2;            // draw with the shared helper on a small canvas
  x2.setTransform(2, 0, 0, 2, 0, 0); drawPuIcon(k, 16, 16, 13, 0);
  ctx = old;
}

// ---------------------------------------------------------------- main loop
let lastT = 0, acc = 0;
const STEP = 1 / 120;
function frame(ts) {
  requestAnimationFrame(frame);
  const now = ts / 1000;
  let dt = Math.min(0.05, now - (lastT || now)); lastT = now;
  if (screen === 'play' && G) {
    const raw = readInput();
    const inp = { left: raw.left, right: raw.right, fire: raw.fire, dx: 0, targetX: mouseAbsX };
    acc += dt;
    let first = true;
    while (acc >= STEP) {
      inp.dx = first ? lockedDX : 0; first = false;
      update(G, STEP, inp); acc -= STEP;
    }
    if (!first) lockedDX = 0;
  } else if (G && (screen === 'result')) {
    updateAmb(G, dt); updateFx(G, dt);
  } else if (!G) {
    menuT += dt;
    if (menuT > 7) { menuT = 0; menuWorld = (menuWorld + 1) % 10; }
  }
  render(G);
  if (!G) drawMenuDecor(dt);
}
let menuT = 0;
const menuAmb = [];
function drawMenuDecor(dt) {
  // floating monsters behind the menu
  fieldTransform(0, 0);
  if (!menuAmb.length) for (let i = 0; i < 9; i++) menuAmb.push({ x: Math.random() * FW, y: Math.random() * FH, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 20, t: Math.random() * 6, k: i });
  for (const m of menuAmb) {
    m.t += dt; m.x += m.vx * dt; m.y += m.vy * dt;
    if (m.x < -60) m.x = FW + 60; if (m.x > FW + 60) m.x = -60; if (m.y < -60) m.y = FH + 60; if (m.y > FH + 60) m.y = -60;
    const w = (menuWorld + m.k) % 10, t = m.k % 3;
    ctx.globalAlpha = 0.9;
    spr('e' + w + '_' + t, m.x, m.y, 0.55, { rot: Math.sin(m.t * 2) * 0.15, sx: 1 + Math.sin(m.t * 4) * 0.05, sy: 1 - Math.sin(m.t * 4) * 0.05 });
  }
  ctx.globalAlpha = 1;
}

// ---------------------------------------------------------------- boot
async function boot() {
  resize();
  window.addEventListener('resize', resize);
  if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) { touchMode = true; document.body.classList.add('touch'); resize(); }
  const v = ASSETS.v || {};
  const q = k => (v[k] ? '?v=' + v[k] : '');
  const jobs = [loadImg('sprites', 'img/sprites.png' + q('sprites'))];
  for (let i = 0; i < 10; i++) jobs.push(loadImg('bg' + i, 'img/bg' + i + '.jpg' + q('bg' + i)));
  // load first background + sprites first, the rest in the background
  await Promise.all([jobs[0], jobs[1]]);
  // local progress (guest until init arrives)
  mergeSave(loadLocal());
  const l = loadLocal(); if (l && typeof l.music === 'boolean') save.music = l.music;
  Snd.setMusic(save.music);
  wireUi();
  applyTexts();
  setScreen('menu');
  document.body.classList.remove('loading');
  requestAnimationFrame(frame);
  post({ type: 'ready' });
  // start menu music on first gesture
  const first = () => { Snd.resume(); if (screen !== 'play') Snd.startMusic(menuWorld, false, true); window.removeEventListener('pointerdown', first, true); window.removeEventListener('keydown', first, true); };
  window.addEventListener('pointerdown', first, true); window.addEventListener('keydown', first, true);
  Promise.all(jobs);
}
boot();

})();
